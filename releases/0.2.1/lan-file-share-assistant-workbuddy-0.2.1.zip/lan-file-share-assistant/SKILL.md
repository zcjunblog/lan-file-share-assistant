---
name: "lan-file-share-assistant"
description: "在可互通的局域网内，用手机或电脑扫码下载指定文件。也可创建专用共享文件夹，放入文件后同一个扫码页自动显示最新内容。分享前检测本机配置，支持自动到期和手动停止。"
display_name: "局域网文件分享助手"
display_name_en: "LAN File Share Assistant"
description_zh: "把需求文档、操作手册、图片或培训资料交给同一局域网的手机和电脑。可以选定一批文件，也可以新建专用共享文件夹。程序先检测本机环境，再生成限时二维码。接收方用浏览器扫码下载。共享文件夹中的文件放入、替换或移出后，同一个页面会更新清单。可随时结束分享，到了截止时间也会自动关闭。文件保留在电脑上。请在互通、可信的局域网内使用，下载通过未加密的 HTTP 传输。"
description_en: "Share documents, manuals, images, or training materials with phones and computers on the same local network. Select files or create a dedicated share folder. After a local readiness check, the skill creates an expiring QR code that opens a browser download page. The same page updates when you add, replace, or remove files in the share folder. Stop sharing whenever you like or let it expire automatically. Your local files remain on your computer. Use a trusted, reachable LAN because downloads use unencrypted HTTP."
author: "zcjunblog"
examples_zh: ["把刚生成的需求确认书分享给我的手机，先检测本地配置，十分钟后关闭。", "建一个专用共享文件夹，放进来的资料用同一个二维码取件，十分钟后关闭。", "停止刚才的文件分享，确认下载入口已关闭、临时副本已清理。"]
examples_en: ["Share the requirements document just generated with my phone. Check local capabilities first and close the share after ten minutes.", "Create a share folder and a QR code that keeps showing the latest files. Close the share after ten minutes.", "Stop the previous share and verify that the listener is closed and temporary copies are removed."]
version: "0.2.1"
---

# 局域网文件分享助手

选择指定文件或创建专用共享文件夹，把资料交付给同一局域网的另一台设备。随附程序负责预检、下载和到期关闭。Agent确认范围并展示已核验的链接。

## 确认本次任务

- 用户要求“建个共享文件夹”或“放进去自动分享”时使用`--folder`。说明这是新建的空目录，放入其中的顶层文件在有效期内可被持码的人下载。
- 固定文件模式列出用户逐项指定的文件。“分享刚生成的文件”可依据本次产物清单确定范围。不要扫描桌面、工作区或默认分享已有目录。
- 默认10分钟，可选1至60分钟；1至20个普通文件，单个不超过2GiB、合计不超过5GiB。macOS已完成5GiB合成本机传输；其他系统及跨设备大文件性能仍待验收。
- 使用可信局域网，HTTP未加密。需要加密、公网、上传或共享已有目录时说明当前范围。
- 核实程序在拥有文件的电脑上执行。只有桌面执行适配器的实际证据或用户对执行位置的确认，才能选择本机参数；私有IP、操作系统名称和请求JSON不能自行证明本机身份。无法判断时以unknown预检，展示需要采取的步骤。

## 准备与运行

对话内收到明确文件和本机执行依据后，直接使用以下两次工具调用。优先使用已有虚拟环境或客户端已知的 Python3.9+。解释器未知时，Windows 先用 `py -3`，命令缺失才试 `python`。`<scripts>` 是本技能的脚本目录，`<runtime>` 是任务下专用私有目录的绝对物理路径。遇到依赖、接口或权限问题再查看[运行与故障处理](references/runtime.md)。

1. 调用程序检查环境并准备会话。`--chat` 会在同一次调用内完成预检和受控探针，结果只包含待核验会话：
   ```sh
   <python> <scripts>/lan_share.py start --chat --work-dir <runtime> --host-kind local --host-evidence desktop_adapter --file <file1> --title "项目交付资料" --ttl-seconds 600
   ```
   `desktop_adapter` 仅用于真实桌面执行适配器，用户确认用 `user_confirmed`。无法确认时用 `--host-kind unknown --host-evidence none`。共享文件夹模式用 `--folder` 代替全部 `--file`。若返回 `blocked`，说明第一项实际失败及修复办法。缺依赖时用同一个解释器按运行参考处理，避免反复寻找环境、重装或自动重试。多网卡时读取候选，选址明确后用 `--bind-address` 指定。
2. 取得 `session_id` 后立即在**下一次独立工具调用**执行核验：
   ```sh
   <python> <scripts>/lan_share.py status --work-dir <runtime> --id <session_id> --wait-seconds 15
   ```
   只有 `state=ready` 且 `can_publish=true` 才立即展示二维码、本机链接、截止时间和文件清单。共享文件夹模式附 `shared_folder`。程序已核验文件读取，无需额外下载或解码二维码。仍在 `preparing` 时及时告知用户文件正在准备，继续核验同一会话。失败、过期或进程不可核验时报告结果，避免反复创建新会话。二维码和链接只交给本次用户，说明 HTTP 未加密以及接收设备连通仍需扫码确认。

用户要求提前停止时执行 `stop`，核对 `stopped` 或 `expired` 及临时资源状态。后台程序会自动到期：
   ```sh
   <python> <scripts>/lan_share.py stop --work-dir <runtime> --id <session_id>
   ```

## 结果与边界

- 共享文件夹模式交付`shared_folder`本机路径、二维码及截止时间。放入、替换和移出文件后，手机页面自动更新。分享停止后，电脑里的文件保留。Windows 本机双击启动方法见[运行与故障处理](references/runtime.md)。
- 默认白蓝移动端页面，自带文件名、大小、下载入口与倒计时；页面刷新不会续期。
- 固定文件模式只读取私有快照，原文件只读。源文件在准备期间改变会阻止分享。ready之后原文件变化不会更新已固定的快照，重新分享应新建会话。
- 到期拒绝新请求、终止未完成传输、关闭监听并清理快照和二维码。已保存副本不能撤回；服务关闭后浏览器可能显示无法连接，不能承诺还能加载“已过期”页面。
- unverified_stale表示无法确认进程。不要展示旧链接、按PID或端口杀进程、恢复旧凭据。异常终止的遗留资源处理见运行参考。
- M3已在macOS的Codex执行工具与WorkBuddy V5.9.3开发包验收本机链路，也取得用户手机验收码回读及停止后失效确认。手机系统/浏览器未提供，手机副本SHA-256未独立核验；Windows/Linux后端已实现，原生CI与真实局域网、客户端、整机睡眠分别验收；兼容性范围以运行参考为准。安装格式通用不代表所有客户端网络能力相同。
- 每次汇报说明已完成内容、当前状态、下一步及未验证项。
