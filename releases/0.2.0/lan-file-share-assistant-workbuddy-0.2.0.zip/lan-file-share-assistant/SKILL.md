---
name: "lan-file-share-assistant"
description: "在可互通的局域网内，用手机或电脑扫码下载指定文件。也可创建专用共享文件夹，放入文件后同一个扫码页自动显示最新内容。分享前检测本机配置，支持自动到期和手动停止。"
display_name: "局域网文件分享助手"
display_name_en: "LAN File Share Assistant"
description_zh: "把需求文档、操作手册、图片或培训资料交给同一局域网的手机和电脑。可以选定一批文件，也可以新建专用共享文件夹。程序先检测本机环境，再生成限时二维码。接收方用浏览器扫码下载。共享文件夹中的文件放入、替换或移出后，同一个页面会更新清单。可随时结束分享，到了截止时间也会自动关闭。文件保留在电脑上。请在互通、可信的局域网内使用，下载通过未加密的 HTTP 传输。"
description_en: "Share documents, manuals, images, or training materials with phones and computers on the same local network. Select files or create a dedicated share folder. After a local readiness check, the skill creates an expiring QR code that opens a browser download page. The same page updates when you add, replace, or remove files in the share folder. Stop sharing whenever you like or let it expire automatically. Your local files remain on your computer. Use a trusted, reachable LAN because downloads use unencrypted HTTP."
author: "zcjunblog"
examples_zh: ["把刚生成的需求确认书分享给我的手机，先检测本地配置，十分钟后关闭。", "建一个专用共享文件夹，放进来的资料用同一个二维码取件，十分钟后关闭。", "停止刚才的文件分享，确认下载入口已关闭、临时副本已清理。"]
examples_en: ["Share the requirements document just generated with my phone. Check local capabilities first and close the share after ten minutes.", "Create a share folder and a QR code that keeps showing the latest files. Close the share after ten minutes.", "Stop the previous share and verify that the listener is closed and temporary copies are removed."]
version: "0.2.0"
---

# 局域网文件分享助手

选择指定文件或创建专用共享文件夹，把资料交付给同一局域网的另一台设备。随附程序负责预检、下载和到期关闭。Agent确认范围并展示已核验的链接。

## 确认本次任务

- 用户要求“建个共享文件夹”或“放进去自动分享”时使用`--folder`。说明这是新建的空目录，放入其中的顶层文件在有效期内可被持码的人下载。
- 固定文件模式列出用户逐项指定的文件。“分享刚生成的文件”可依据本次产物清单确定范围。不要扫描桌面、工作区或默认分享已有目录。
- 默认10分钟，可选1至60分钟；1至20个普通文件，单个不超过2GiB、合计不超过5GiB。macOS已完成5GiB合成本机传输；其他系统及跨设备大文件性能仍待验收。
- 使用可信局域网，HTTP未加密。需要加密、公网、上传或共享已有目录时说明当前范围。
- 核实程序在拥有文件的电脑上执行。只有桌面执行适配器的实际证据或用户对执行位置的确认，才能选择本机参数；私有IP、操作系统名称和请求JSON不能自行证明本机身份。无法判断时以unknown预检，展示需要采取的步骤。

## 准备与运行

首次运行或遇到依赖、接口、停止问题时，阅读[运行与故障处理](references/runtime.md)。选择可运行Python3.9+和Segno1.6.6的解释器；不使用开发者的绝对路径，也不改全局环境。`<scripts>`表示本Skill的scripts目录，`<runtime>`是用户任务下一个新的专用目录，使用绝对物理路径。该目录保存凭据，POSIX权限0700；Windows使用仅当前用户的原生私有ACL。不能复用普通资料目录。

1. 用同一解释器执行：
   ```sh
   <python> <scripts>/lan_share.py probe --work-dir <runtime>
   ```
   此步骤没有文件服务。取得probe_id后，在**下一次独立执行工具调用**的60秒内继续；同一脚本里串联probe和start不能证明跨调用存活。
2. 根据确立的本机依据、文件授权与有效期直接执行`start`，程序已包含完整预检：
   ```sh
   <python> <scripts>/lan_share.py start --work-dir <runtime> --probe-id <probe_id> --host-kind local --host-evidence desktop_adapter --file <file1> --file <file2> --title "项目交付资料" --ttl-seconds 600
   ```
   `desktop_adapter`仅用于真实桌面执行适配器。用户确认用`user_confirmed`。不确定时使用`--host-kind unknown --host-evidence none`，不得为通过检测伪造依据。共享文件夹模式用`--folder`代替全部`--file`参数。用户只要求检测时才运行`preflight`。
3. 若返回blocked，按八项检查中的reason_code、summary、remediation说明具体原因和复检方法；不生成假链接。多网卡时用`interfaces`读取候选，确定实际连接用途后`--bind-address`选择，无法确定则请用户选择。不要修改VPN、防火墙、路由或停止其他进程。
4. preparing表示快照尚在准备；用status轮询，不称分享成功。无论start是否返回ready，在**下一次独立工具调用**执行：
   ```sh
   <python> <scripts>/lan_share.py status --work-dir <runtime> --id <session_id>
   ```
   只有`state=ready`且`can_publish=true`才展示链接和qr_png/qr_svg。有效期从服务就绪开始，跨调用核验和生成回复也会消耗时间；一分钟这类短会话尤其需要及时交付。可以在同一次独立status调用中完成本机下载摘要验证，但probe与后续启动仍须跨调用。到期如实说明，重新分享遵循用户授权的期限，不静默续期。将二维码作为本地图片展示，并给出文件清单、截止时间、HTTP提示和停止方式。链接和二维码含访问凭据，仅交给本次用户，不上传公共图床、仓库或外部二维码网站。
5. 明确“本机启动自检通过；另一设备连通尚未验证”。用户手机完成下载后才记录实际跨设备结果；电脑上的二维码解码、本机访问不等于手机验收。
6. 用户要求提前停止时执行stop，等待stopped/expired并确认temporary_resources_removed。到期由后台程序强制执行，无需Agent定时提醒：
   ```sh
   <python> <scripts>/lan_share.py stop --work-dir <runtime> --id <session_id>
   ```

## 结果与边界

- 共享文件夹模式交付`shared_folder`本机路径、二维码及截止时间。放入、替换和移出文件后，手机页面自动更新。分享停止后，电脑里的文件保留。Windows 本机双击启动方法见[运行与故障处理](references/runtime.md)。
- 默认白蓝移动端页面，自带文件名、大小、下载入口与倒计时；页面刷新不会续期。
- 固定文件模式只读取私有快照，原文件只读。源文件在准备期间改变会阻止分享。ready之后原文件变化不会更新已固定的快照，重新分享应新建会话。
- 到期拒绝新请求、终止未完成传输、关闭监听并清理快照和二维码。已保存副本不能撤回；服务关闭后浏览器可能显示无法连接，不能承诺还能加载“已过期”页面。
- unverified_stale表示无法确认进程。不要展示旧链接、按PID或端口杀进程、恢复旧凭据。异常终止的遗留资源处理见运行参考。
- M3已在macOS的Codex执行工具与WorkBuddy V5.9.3开发包验收本机链路，也取得用户手机验收码回读及停止后失效确认。手机系统/浏览器未提供，手机副本SHA-256未独立核验；Windows/Linux后端已实现，原生CI与真实局域网、客户端、整机睡眠分别验收；兼容性范围以运行参考为准。安装格式通用不代表所有客户端网络能力相同。
- 每次汇报说明已完成内容、当前状态、下一步及未验证项。
